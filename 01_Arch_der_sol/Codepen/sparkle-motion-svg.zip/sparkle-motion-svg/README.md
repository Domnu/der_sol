# Sparkle Motion SVG ✨

A Pen created on CodePen.io. Original URL: [https://codepen.io/leimapapa/pen/XWGMrvo](https://codepen.io/leimapapa/pen/XWGMrvo).

"Sometimes I doubt your commitment to sparkle motion!"

Based loosely on (idea stolen entirely from) Ryan Mulligan's pen: https://codepen.io/hexagoncircle/pen/bGZdWyw