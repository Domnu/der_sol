from django.apps import AppConfig


class MastersConfig(AppConfig):
    name = 'masters'
