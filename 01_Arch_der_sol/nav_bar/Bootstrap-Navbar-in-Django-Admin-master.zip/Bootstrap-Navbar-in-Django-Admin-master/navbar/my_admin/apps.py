from django.apps import AppConfig


class MyAdminConfig(AppConfig):
    name = 'my_admin'
