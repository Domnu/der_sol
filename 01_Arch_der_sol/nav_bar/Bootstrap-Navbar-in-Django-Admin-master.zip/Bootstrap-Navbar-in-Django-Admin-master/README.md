This repository is created for this tutorial: https://medium.com/crowdbotics/how-to-add-a-navigation-menu-in-django-admin-770b872a9531
